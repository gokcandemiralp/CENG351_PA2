import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CengTreeNodeInternal extends CengTreeNode
{
    private ArrayList<Integer> keys;
    private ArrayList<CengTreeNode> children;
    public boolean isRoot;

    public CengTreeNodeInternal(CengTreeNode parent)
    {
        super(parent);
        this.isRoot = false;
        this.keys = new ArrayList<Integer>();
        this.children = new ArrayList<CengTreeNode>();
        // TODO: Extra initializations, if necessary.
    }

    // GUI Methods - Do not modify
    public ArrayList<CengTreeNode> getAllChildren()
    {
        return this.children;
    }
    public Integer keyCount()
    {
        return this.keys.size();
    }
    public Integer keyAtIndex(Integer index)
    {
        if(index >= this.keyCount() || index < 0)
        {
            return -1;
        }
        else
        {
            return this.keys.get(index);
        }
    }

    // Extra Functions

    public void addKeyAndChild(CengTreeNode splittedLeaf){
        if(this.keyCount() < order*2){ // just leaf overflowing
            int tempKeyInsertionIndex = this.addKey(splittedLeaf.upperOverflowKey) + 1;
            this.addChild(splittedLeaf,tempKeyInsertionIndex, splittedLeaf.type);
        }
        else if(this.isRoot){ //root overflowing
            this.overflowRoot(splittedLeaf);
        }
        else{
            CengTreeNodeInternal splittedInternalNode = this.overflowInternal(splittedLeaf);
            ((CengTreeNodeInternal)this.getParent()).addKeyAndChild(splittedInternalNode);
            //System.out.println("correct if else structure");
        }
    }
    public int addKey(int key){
        int index = Collections.binarySearch(keys, key);
        int insertionLocation = (index < 0) ? -index - 1 : index;
        keys.add(insertionLocation, key);
        return insertionLocation;
    }

    public int addChild(CengTreeNode newChild, int keyInsertionIndex, CengNodeType type){
        newChild.setParent(this);
        newChild.type = type;
        children.add(keyInsertionIndex, newChild);
        return -1;
    }

    public CengTreeNodeInternal overflowInternal(CengTreeNode splittedChildNode){
        CengTreeNodeInternal splittedInternalNode = new CengTreeNodeInternal(this.getParent());
        splittedInternalNode.type = CengNodeType.Internal;

        ArrayList<Integer> tempKeys = keys;
        ArrayList<CengTreeNode> tempChildren = children;

        ArrayList<Integer> remainingKeys = new ArrayList<Integer>();
        ArrayList<CengTreeNode> remainingChildren = new ArrayList<CengTreeNode>();

        int index = Collections.binarySearch(tempKeys, splittedChildNode.upperOverflowKey);
        int insertionLocation = (index < 0) ? -index - 1 : index;
        tempKeys.add(insertionLocation, splittedChildNode.upperOverflowKey);
        tempChildren.add(insertionLocation + 1,splittedChildNode);

        for(int i = 0 ; i < order ; ++i){
            remainingKeys.add(tempKeys.get(i));
        }
        for(int i = 0 ; i < order + 1 ; ++i){
            remainingChildren.add(tempChildren.get(i));
        }

        for(int i = order + 1; i <= order*2 ; ++i){
            splittedInternalNode.addKey(tempKeys.get(i));
        }
        for(int i = order + 1, n = 0; i <= order*2 + 1 ; ++i){
            splittedInternalNode.addChild(tempChildren.get(i),n,splittedChildNode.type);
            ++n;
        }

        keys = remainingKeys;
        children = remainingChildren;

        splittedInternalNode.upperOverflowKey = tempKeys.get(order);
        return splittedInternalNode;
    }
    public int overflowRoot(CengTreeNode splittedChildNode){
        CengTreeNodeInternal splittedNodeLeft = new CengTreeNodeInternal(this);
        splittedNodeLeft.type = CengNodeType.Internal;
        CengTreeNodeInternal splittedNodesRight = new CengTreeNodeInternal(this);
        splittedNodesRight.type = CengNodeType.Internal;

        ArrayList<Integer> tempKeys = keys;
        ArrayList<CengTreeNode> tempChildren = children;

        ArrayList<Integer> remainingKeys = new ArrayList<Integer>();
        ArrayList<CengTreeNode> remainingChildren = new ArrayList<CengTreeNode>();

        int index = Collections.binarySearch(tempKeys, splittedChildNode.upperOverflowKey);
        int insertionLocation = (index < 0) ? -index - 1 : index;
        tempKeys.add(insertionLocation, splittedChildNode.upperOverflowKey);
        tempChildren.add(insertionLocation + 1,splittedChildNode);

        splittedNodeLeft.upperOverflowKey = tempKeys.get(0);
        for(int i = 0 ; i < order ; ++i){
            splittedNodeLeft.addKey(tempKeys.get(i));
        }
        for(int i = 0 ; i < order + 1 ; ++i){
            splittedNodeLeft.addChild(tempChildren.get(i),i,splittedChildNode.type);
        }

        splittedNodesRight.upperOverflowKey = tempKeys.get(order + 1);
        for(int i = order + 1; i <= order*2 ; ++i){
            splittedNodesRight.addKey(tempKeys.get(i));
        }
        for(int i = order + 1, n = 0; i <= order*2 + 1 ; ++i){
            splittedNodesRight.addChild(tempChildren.get(i),n,splittedChildNode.type);
            ++n;
        }

        remainingKeys.add(tempKeys.get(order));
        remainingChildren.add(splittedNodeLeft);
        remainingChildren.add(splittedNodesRight);
        keys = remainingKeys;
        children = remainingChildren;

        return -1;
    }

    public int searchPointer(int key){
        int index = Collections.binarySearch(keys, key);
        int insertionLocation = (index < 0) ? -index - 1 : index;
        return insertionLocation;
    }

    public int searchBook(int bookID){
        for (int i = 0; i < keys.size(); i++) {
            int key = keys.get(i);
            if (key > bookID) {
                return i;
            }
        }
        return keys.size();
    }

    public void printKeys(int printLevel){
        for(int i = 0 ; i< this.keyCount(); ++i){
            System.out.println("\t".repeat(printLevel) + this.keyAtIndex(i));
        }
    }
}
