import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CengTreeNodeLeaf extends CengTreeNode
{
    private ArrayList<CengBook> books;
    // TODO: Any extra attributes

    public CengTreeNodeLeaf(CengTreeNode parent)
    {
        super(parent);
        this.books = new ArrayList<CengBook>();
        // TODO: Extra initializations
    }

    // GUI Methods - Do not modify
    public int bookCount()
    {
        return books.size();
    }
    public Integer bookKeyAtIndex(Integer index)
    {
        if(index >= this.bookCount()) {
            return -1;
        } else {
            CengBook book = this.books.get(index);

            return book.getBookID();
        }
    }
    public Integer searchBook(Integer bookID) {
        for (int i = 0; i < books.size(); i++) {
            CengBook element = books.get(i);
            if (element.getBookID().equals(bookID)) {
                return i;
            }
        }
        return -1;
    }
    public int addBook(CengBook book){
        int index = Collections.binarySearch(books, book, Comparator.comparingInt(CengBook::getBookID));
        int insertionLocation = (index < 0) ? -index - 1 : index;
        books.add(insertionLocation, book);
        return -1;
    }

    public CengTreeNodeLeaf overflowLeaf(CengBook book){
        CengTreeNodeLeaf splittedLeaf = new CengTreeNodeLeaf(this.getParent());
        ArrayList<CengBook> remainingBooks = new ArrayList<CengBook>();
        splittedLeaf.type = CengNodeType.Leaf;

        ArrayList<CengBook> tempBooks = books;
        int index = Collections.binarySearch(tempBooks, book, Comparator.comparingInt(CengBook::getBookID));
        int insertionLocation = (index < 0) ? -index - 1 : index;
        tempBooks.add(insertionLocation, book);

        for(int i = 0 ; i < order ; ++i){
            remainingBooks.add(tempBooks.get(i));
        }
        books = remainingBooks;

        splittedLeaf.upperOverflowKey = tempBooks.get(order).getBookID();
        for(int i = order ; i <= order*2 ; ++i){
            splittedLeaf.addBook(tempBooks.get(i));
        }

        return splittedLeaf;
    }
    public int overflowLeaf(CengBook book, CengTreeNodeLeaf[] splittedLeafs){
        splittedLeafs[0] = new CengTreeNodeLeaf(null);
        splittedLeafs[1] = new CengTreeNodeLeaf(null);

        ArrayList<CengBook> tempBooks = books;
        int index = Collections.binarySearch(tempBooks, book, Comparator.comparingInt(CengBook::getBookID));
        int insertionLocation = (index < 0) ? -index - 1 : index;
        tempBooks.add(insertionLocation, book);

        for(int i = 0 ; i < order ; ++i){
            splittedLeafs[0].addBook(tempBooks.get(i));
        }
        for(int i = order ; i <= order*2 ; ++i){
            splittedLeafs[1].addBook(tempBooks.get(i));
        }

        return tempBooks.get(order).getBookID();
    }
    public Integer printBookRecord(Integer bookID, int printLevel) {
        for (int i = 0; i < books.size(); i++) {
            CengBook element = books.get(i);
            if (element.getBookID().equals(bookID)) {
                CengBook cengBook = books.get(i);
                System.out.println( "\t".repeat(printLevel) +
                        "<record>" +
                        cengBook.fullName() +
                        "</record>");
                return i;
            }
        }
        System.out.println("Could not find bookID");
        return -1;
    }
    public void printRecords(int printLevel){
        for(int i = 0 ; i< this.books.size(); ++i){
            CengBook cengBook = books.get(i);
            System.out.println( "\t".repeat(printLevel) +
                    "<record>" +
                    cengBook.fullName() +
                    "</record>");
        }
    }
}
