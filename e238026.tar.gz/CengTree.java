import java.util.ArrayList;

public class CengTree
{
    public CengTreeNode root;
    public int order ;
    // Any extra attributes...

    public CengTree(Integer order)
    {
        // TODO: Initialize the class
        CengTreeNode.order = order;
        CengTreeNode.objectIdCount = 0;

        this.order = order;
        root = new CengTreeNodeLeaf(null);
        root.type = CengNodeType.Leaf;
    }

    public void addBook(CengBook book) {

        CengTreeNode targetNode = root;
        if(root.type == CengNodeType.Internal ){ // find the leaf that belongs
            while(targetNode.type == CengNodeType.Internal){
                int targetIndex = ((CengTreeNodeInternal) targetNode).searchPointer(book.getBookID());
                ArrayList<CengTreeNode> children = ((CengTreeNodeInternal) targetNode).getAllChildren();
                targetNode = children.get(targetIndex);
            }
            if(((CengTreeNodeLeaf)targetNode).bookCount() < this.order * 2 ){ // no overflow
                ((CengTreeNodeLeaf)targetNode).addBook(book);
            }
            else{ // leaf overflow
                CengTreeNodeInternal parentNode = (CengTreeNodeInternal)targetNode.getParent();
                CengTreeNodeLeaf splittedLeaf = ((CengTreeNodeLeaf)targetNode).overflowLeaf(book);
                parentNode.addKeyAndChild(splittedLeaf);
            }
        }

        else{                                                               //root is a leaf
            if(((CengTreeNodeLeaf)root).bookCount() < this.order * 2 ){    // in root there is still room
                ((CengTreeNodeLeaf)targetNode).addBook(book);
            }
            else{                                                           //root overflow
                CengTreeNodeLeaf[] splittedLeafs;
                splittedLeafs = new CengTreeNodeLeaf[2];
                int tempKey = ((CengTreeNodeLeaf)root).overflowLeaf(book, splittedLeafs);
                root = new CengTreeNodeInternal(null);
                root.type = CengNodeType.Internal;
                ((CengTreeNodeInternal) root).isRoot = true;
                ((CengTreeNodeInternal) root).addKey(tempKey);
                ((CengTreeNodeInternal) root).addChild(splittedLeafs[0],0, CengNodeType.Leaf);
                ((CengTreeNodeInternal) root).addChild(splittedLeafs[1],1, CengNodeType.Leaf);
            }
        }
    }

    public ArrayList<CengTreeNode> searchBook(Integer bookID)
    {
        // TODO: Search within whole Tree, return visited nodes.

        ArrayList<CengTreeNode> result = new ArrayList<CengTreeNode>();
        CengTreeNode targetNode = root;
        int printLevel = 0;

        int recursionResult = 0;
        if(targetNode.type == CengNodeType.Internal ) {
            recursionResult = searchIndexNode(bookID,((CengTreeNodeInternal)targetNode),result,printLevel, false);
        }
        else if(targetNode.type == CengNodeType.Leaf ){
            recursionResult = searchLeafNode(bookID,((CengTreeNodeLeaf)targetNode),result,printLevel, false);
        }

        result = new ArrayList<CengTreeNode>();
        targetNode = root;
        printLevel = 0;
        boolean shouldPrint = (recursionResult == 0);

        if(shouldPrint){
            if(targetNode.type == CengNodeType.Internal ) {
                recursionResult = searchIndexNode(bookID,((CengTreeNodeInternal)targetNode),result,printLevel, shouldPrint);
            }
            else if(targetNode.type == CengNodeType.Leaf ){
                recursionResult = searchLeafNode(bookID,((CengTreeNodeLeaf)targetNode),result,printLevel, shouldPrint);
            }
        }
        else{
            System.out.println("Could not find " + bookID);
        }

        return result;
    }

    public int searchIndexNode(Integer bookID, CengTreeNodeInternal targetNode, ArrayList<CengTreeNode> result, int printLevel, boolean shouldPrint){

        result.add(0,targetNode);
        if(shouldPrint){
            System.out.println("\t".repeat(printLevel) + "<index>");
            targetNode.printKeys(printLevel);
            System.out.println("\t".repeat(printLevel) + "</index>");
        }

        int targetIndex = targetNode.searchBook(bookID);
        ArrayList<CengTreeNode> children = targetNode.getAllChildren();
        CengTreeNode nextNode = children.get(targetIndex);

        if(nextNode.type == CengNodeType.Internal ) {
            return searchIndexNode(bookID,((CengTreeNodeInternal)nextNode),result, printLevel + 1, shouldPrint);
        }
        else if(nextNode.type == CengNodeType.Leaf ){
            return searchLeafNode(bookID,((CengTreeNodeLeaf)nextNode),result, printLevel + 1, shouldPrint);
        }
        return -1;
    }

    public int searchLeafNode(Integer bookID, CengTreeNodeLeaf targetNode,ArrayList<CengTreeNode> result, int printLevel, boolean shouldPrint){
        if(targetNode.searchBook(bookID) >= 0){
            result.add(0,targetNode);
            if(shouldPrint){
                targetNode.printBookRecord(bookID,printLevel);
            }
            return 0;
        }
        else{
            result = new ArrayList<CengTreeNode>();
            return -1;
        }
    }

    public void printTree() {
        // TODO: Print the whole tree to console

        if(root.type == CengNodeType.Internal ) {
            printIndexNodes(((CengTreeNodeInternal)root),0);
        }
        if(root.type == CengNodeType.Leaf ){
            printDataNodes(((CengTreeNodeLeaf)root),0);
        }
    }

    // Any extra functions...

    public void printIndexNodes(CengTreeNodeInternal targetNode, int printLevel) {
        System.out.println("\t".repeat(printLevel) + "<index>");
        targetNode.printKeys(printLevel);
        System.out.println("\t".repeat(printLevel) + "</index>");

        ArrayList<CengTreeNode> children = targetNode.getAllChildren();
        if(children.size()>0){
            if(children.get(0).type == CengNodeType.Leaf){
                for(int i = 0 ; i < children.size() ; ++i){
                    printDataNodes(((CengTreeNodeLeaf)children.get(i)),printLevel+1);
                }
            }
            if(children.get(0).type == CengNodeType.Internal){
                for(int i = 0 ; i < children.size() ; ++i){
                    printIndexNodes(((CengTreeNodeInternal)children.get(i)),printLevel+1);
                }
            }
        }
    }

    public void printDataNodes(CengTreeNodeLeaf targetNode, int printLevel) {
        System.out.println("\t".repeat(printLevel) + "<data>");
        targetNode.printRecords(printLevel);
        System.out.println("\t".repeat(printLevel) + "</data>");
    }
}
