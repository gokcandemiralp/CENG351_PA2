import java.io.IOException;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;
import java.util.Objects;
import java.util.Scanner;

public class CengTreeParser
{
    public static ArrayList<CengBook> parseBooksFromFile(String filename)
    {
        ArrayList<CengBook> bookList = new ArrayList<CengBook>();

        try (FileReader fileReader = new FileReader(filename);
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 4) {
                    CengBook tempCengBook = new CengBook(Integer.valueOf(parts[0]),parts[1],parts[2],parts[3]);
                    bookList.add(tempCengBook);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return bookList;
    }

    public static void startParsingCommandLine() throws IOException
    {
        // TODO: Start listening and parsing command line -System.in-.

        Scanner sc = new Scanner(System.in);
        String command = "";

        // There are 4 commands:
        // 1) quit : End the app, gracefully. Print nothing, call nothing, just break off your command line loop.
        while(true) {
            // 2) add : Parse and create the book, and call CengBookRunner.addBook(newlyCreatedBook).
            if (command.equalsIgnoreCase("quit")) {break;}
            try {command = sc.nextLine();}
            catch (Exception e){continue;}

            String[] partsAdd = command.split("\\|");
            if (partsAdd.length == 5 && Objects.equals(partsAdd[0], "add")) {
                CengBook createBook = new CengBook(Integer.parseInt(partsAdd[1]), partsAdd[2], partsAdd[3], partsAdd[4]);
                CengBookRunner.addBook(createBook);
            }
            // 3) search : Parse the bookID, and call CengBookRunner.searchBook(bookID).
            String[] partsSearch = command.split(" ");
            if (partsSearch.length == 2 && command.startsWith("search")) {
                int bookID = Integer.parseInt(partsSearch[1]);
                CengBookRunner.searchBook(bookID);
            }
            // 4) print : Print the whole tree, call CengBookRunner.printTree().
            if(command.startsWith("print")) {
                CengBookRunner.printTree();
            }
        }
        System.exit(-1);
        // Commands (quit, add, search, print) are case-insensitive.
    }
}
